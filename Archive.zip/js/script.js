openNav = () => {
  document.getElementById("navMobile").style.display = "block";
  document.getElementById("navMobile").style.height = "100vh";
};
closeNav = () => {
  document.getElementById("navMobile").style.display = "none";
  document.getElementById("navMobile").style.height = "0vh";
};
